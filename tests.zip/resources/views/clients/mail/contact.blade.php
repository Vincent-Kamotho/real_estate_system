{{-- <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Email</title>

        <body>
            <h1>Your message has been sent</h1>
            <p>Thank you for contacting us. We will get back to you as soon as possible </p>
        </body>
    </head> --}}

    {{$body}}