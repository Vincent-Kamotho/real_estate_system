

    <?php echo e($body); ?><?php /**PATH C:\xampp\htdocs\learning\real_estate_system\resources\views/clients/mail/contact.blade.php ENDPATH**/ ?>