<div class="sidebar">
    <div class="logo"></div>
    <ul class="menu">
        <li class="active">
            <a href="<?php echo e(route('admin_home')); ?>">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('show_listings')); ?>">
                <i class="fas fa-list"></i>
                <span>Listings</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('owners')); ?>">
                <i class="fa fa-male"></i>
                <span>Owners</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fas fa-users"></i>
                <span>Users</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fas fa-question-circle"></i>
                <span>Leads/Inquiries</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fas fa-bar-chart"></i>
                <span>Analytics</span>
            </a>
        </li>
        <li>
            <a href="#">
                <i class="fa fa-credit-card-alt"></i>
                <span>Transactions</span>
            </a>
        </li>
        
        <li>
            <a href="#">
                <i class="fas fa-cog"></i>
                <span>Settings</span>
            </a>
        </li>

        <li class="logout">
            <a href="#">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </li>
        
        <li class="logout">
            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>>

                
                
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>



        
    </ul>
</div><?php /**PATH C:\xampp\htdocs\learning\real_estate_system\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>