<div class="header--wrapper">
    <div class="header--title">
        <span>Primary</span>
        <h2>Real Estate System</h2>
    </div>
    <div class="user--info">
        <div class="searh--box">
            <i class="fa-solid fa-search"></i>
            <input type="text" placeholder="search"/>
            <img src="./image/img.jpg" alt=""/>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\learning\real_estate_system\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>